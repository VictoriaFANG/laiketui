<?php
define('MYSQL_TYPE','mysql');
define('MYSQL_USE',true);
define('MYSQL_SERVER','127.0.0.1');
define('MYSQL_USER','root');
define('MYSQL_PASSWORD','root');
define('MYSQL_DATABASE','open');