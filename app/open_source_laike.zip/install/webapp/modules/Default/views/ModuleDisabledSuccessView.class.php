<?php

class ModuleDisabledSuccessView extends SmartyView
{

    public function execute ()
    {

        // set our template
        $this->setTemplate('ModuleDisabledSuccess.tpl');

    }

}

?>