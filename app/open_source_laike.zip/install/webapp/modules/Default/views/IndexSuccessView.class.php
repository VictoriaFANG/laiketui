<?php

class IndexSuccessView extends SmartyView
{
    public function execute ()
    {
        // set our template
        $this->setTemplate('IndexSuccess.tpl');

    }

}

?>