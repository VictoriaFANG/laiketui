<?php

class UnavailableSuccessView extends SmartyView
{

    public function execute ()
    {

        // set our template
        $this->setTemplate('UnavailableSuccess.tpl');

    }

}

?>