<?php

class Error404SuccessView extends SmartyView
{

    public function execute ()
    {

        // set our template
        $this->setTemplate('Error404Success.tpl');

    }

}

?>