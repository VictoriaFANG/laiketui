<?php

class SecureSuccessView extends SmartyView
{

    public function execute ()
    {

        // set our template
        $this->setTemplate('SecureSuccess.tpl');

    }

}

?>